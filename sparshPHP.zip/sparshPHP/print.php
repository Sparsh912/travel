<?php

echo "Hello world";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php
        echo "this is ";
        echo "title"; 
        ?>
    </title>
</head>
<body>
<?php

echo "Hello world";

?>
</body>
</html>
